var inputs = 0;
var form = document.forms.myForm;
if(form){
    form.getElementsByTagName('div').length;
    form.addEventListener('click', function(event){
        event.preventDefault();
        if(event.target.name == 'add'){
            form.appendChild(event.target.parentNode.cloneNode(true));
            inputs++;
        }
        if(event.target.name == 'del'){
            if(inputs > 0){
                form.removeChild(event.target.parentNode);
                inputs--;
            }
        }
    });
}

var btn = document.querySelector('#btn'),
    out = document.querySelector('#out'),
    range = document.querySelector('#range'),
    rasstoyanie = document.querySelector('.rasstoyanie').innerHTML = 1;
    vol = document.querySelector('#vol'),
    kub = 30000,
 // range slider
    range.onchange = function(){
      var rasstoyanie = document.querySelector('.rasstoyanie').innerHTML = range.value;
    }
  // Basic function  
btn.onclick = function(){
var sum =kub*range.value;
      out.innerHTML = sum;
}

