window.onload = function(){ 
function password(){

  var password = (document.getElementById('password').value);
  if(password.length < 5)
  {
    document.getElementById("okno").style.display = "block";
  }else{
     document.getElementById("okno").style.display = "none";
  }

 
    

if(password.length != 0){
  for(var i = 0;i < password.length;i++)
  {
    for(var j = 0; j <= massiv.length; j++)
    {
        if (password[i] == massiv[j])
        {
            k++
        }
    }
} 
  
  if(k < 1)
  {
    document.getElementById("okno1").style.display = "block";
  }
} 



}
var massiv = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
var k = 0;
var check = document.getElementById('knopka'); 
check.onclick = password;
var form = document.querySelector('form');
};
